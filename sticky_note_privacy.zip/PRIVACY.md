# Privacy Policy

Sticky Note Everywhere does not collect, transmit, or sell personal data.

- Notes are stored locally in `chrome.storage.local`.
- Lightweight UI state (such as titles, pinned/visible flags, and positions) may be stored in `chrome.storage.sync` to sync between Chrome profiles.
- The extension does not use external servers, analytics, or trackers.

If you have questions or feedback, please use the Support link provided in the Chrome Web Store listing.
